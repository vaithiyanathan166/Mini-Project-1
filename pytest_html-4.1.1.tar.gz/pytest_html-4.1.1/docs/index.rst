.. pytest-html documentation master file, created by
   sphinx-quickstart on Sun Dec  6 20:48:43 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pytest-html
===========

pytest-html is a plugin for `pytest`_ that generates a HTML report for test results.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installing
   user_guide
   api_reference
   development
   changelog
   deprecations

.. _pytest: http://pytest.org
